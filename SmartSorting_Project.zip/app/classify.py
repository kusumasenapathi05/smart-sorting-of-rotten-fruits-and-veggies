
import cv2
from keras.models import load_model
import numpy as np

model = load_model('../models/cnn_model.h5')

def preprocess(image_path):
    img = cv2.imread(image_path)
    img = cv2.resize(img, (64, 64))
    img = img.astype('float32') / 255
    return np.expand_dims(img, axis=0)

def predict(image_path):
    image = preprocess(image_path)
    prediction = model.predict(image)
    return "Fresh" if prediction[0][0] < 0.5 else "Rotten"

if __name__ == "__main__":
    import sys
    result = predict(sys.argv[1])
    print(f"Prediction: {result}")
