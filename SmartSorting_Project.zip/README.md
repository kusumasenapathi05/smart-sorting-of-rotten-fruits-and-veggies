# Smart Sorting of Rotten Fruits and Vegetables Using AI and ML
