
# Utility functions for image preprocessing (resizing, normalization)
def resize_image(img, size=(64, 64)):
    import cv2
    return cv2.resize(img, size)
